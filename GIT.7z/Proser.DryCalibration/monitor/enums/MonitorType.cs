﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proser.DryCalibration.monitor.enums
{
    public enum MonitorType
    {
        RTD = 1,
        Pressure,
        Ultrasonic
    }
}
