﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proser.DryCalibration.sensor.ultrasonic.enums
{

    public enum AddressPointFormat
    {
        Floating= 0,
        Integer
    }

    
}
