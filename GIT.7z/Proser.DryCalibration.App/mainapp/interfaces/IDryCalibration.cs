﻿

namespace Proser.DryCalibration.App.mainapp.interfaces
{
    public interface IDryCalibration
    {
       
    }
}